package edu.eci.cvds.ecitv.model;

/**
 * The available subscription categories.
 */
public enum SubscriptionCategory {

	SILVER,
	GOLD,
	DIAMOND;
}
