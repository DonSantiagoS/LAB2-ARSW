package edu.eci.cvds.ecitv.service;

import java.math.BigDecimal;

import edu.eci.cvds.ecitv.model.SubscriptionCategory;

/**
 * Subscription Service class in charge of calculating the monthly subscription.
 */
public class SubscriptionService {

	private BigDecimal costoSilver= new BigDecimal(15000);
	private BigDecimal costoGold= new BigDecimal(20000);
	private BigDecimal costoDiamond= new BigDecimal(30000);
	private BigDecimal descuento1= new BigDecimal(0.15);
	private BigDecimal descuento2= new BigDecimal(0.12);
	private BigDecimal descuento3= new BigDecimal(0.1);
	private BigDecimal descuento4= new BigDecimal(0.2);
	/**
	 * Calculate the cost of sucribing for the tc service, depending on the subscription category and the age of the client.
	 * Calculate the cost of sucribing for the tc service, depending on the subscription category and the age of the client.
	 * Calculate the cost of sucribing for the tc service, depending on the subscription category and the age of the client.
	 *
	 * @param age            the age of the client
	 * @param subCategory    The subscription category
	 * @return The amount to be charged to the client
	 */
	public BigDecimal calculateCost(final Integer age, final SubscriptionCategory subCategory) {
		BigDecimal costoTotal= new BigDecimal(0);
		if (subCategory==SubscriptionCategory.SILVER){costoTotal=costoTotal.add(costoSilver);}
		else if (subCategory==SubscriptionCategory.GOLD){costoTotal=costoTotal.add(costoGold);}
		else if (subCategory==SubscriptionCategory.DIAMOND){costoTotal=costoTotal.add(costoDiamond);}
		
		
		if (age>17 && age<26){costoTotal=costoTotal.subtract( costoTotal.multiply(descuento1));}
		else if (age>25 && age<31){costoTotal= costoTotal.subtract(costoTotal.multiply(descuento2));}
		else if (age>30 && age<61){costoTotal=costoTotal.subtract( costoTotal.multiply(descuento3));}
		else if (age>60 && age<151){costoTotal= costoTotal.subtract(costoTotal.multiply(descuento4));}
		else {return BigDecimal.ZERO;}
		BigDecimal value = costoTotal.setScale(0, BigDecimal.ROUND_HALF_UP);
		return value;
	}

	/*
	 * Tip: Siempre que se desee realizar cálculos matemáticos de alta precisión (por ejemplo para temas de dinero)
	 * es mucho más confiable usar el tipo de dato BigDecimal, pues soporta un alto rango de número, decimales y
	 * tiene mayor precisión en los cálculos. <br />
	 * Ejemplos básicos de operaciones con BigDecimal, teniendo las variables `bd1` y `bd2`:
	 * <ul>
	 * <li>Creación: <code>BigDecimal nuevo = new BigDecimal(10);</code></li>
	 * <li>Sumas: <code>BigDecimal suma = bd1.add(bd2);</code></li>
	 * <li>Restas: <code>BigDecimal resta = bd1.subtract(bd2);</code></li>
	 * <li>Multiplicación: <code>BigDecimal multiplicacion = bd1.multiply(bd2);</code></li>
	 * <li>División: <code>BigDecimal division = bd1.divide(bd2);</code></li>
	 * </ul>
	 */

}

