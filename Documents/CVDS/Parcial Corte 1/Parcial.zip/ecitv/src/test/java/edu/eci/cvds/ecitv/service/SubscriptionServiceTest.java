package edu.eci.cvds.ecitv.service;

import edu.eci.cvds.ecitv.model.SubscriptionCategory;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test class for {@link SubscriptionService}
 CLASES DE EQUIVALENCIA						
						
Clase 1	age<18 || age>150					Invalido
Clase 2	subCategory!=DIAMOND || subCategory!=GOLD || subCategory!=SILVER					Invalido
Clase 2	18<=age<=25					Valido
Clase 3	26<=age<=30					Valido
Clase 4	31<=age<=60					Valido
Clase 5	61<=age<=150					Valido

 
 */
public class SubscriptionServiceTest {

		private BigDecimal costoSilver= new BigDecimal(15000);
	private BigDecimal costoGold= new BigDecimal(20000);
	private BigDecimal costoDiamond= new BigDecimal(30000);
	private BigDecimal descuento1= new BigDecimal(0.15);
	private BigDecimal descuento2= new BigDecimal(0.12);
	private BigDecimal descuento3= new BigDecimal(0.1);
	private BigDecimal descuento4= new BigDecimal(0.2);
	/**
	 * PRUEBAS
	 */
	private SubscriptionService service = new SubscriptionService();
	 
	
	/**
	 * Clase 1
	 */
	@Test
	public void limiteInferior() {
		BigDecimal costo=service.calculateCost(17,SubscriptionCategory.SILVER); 
		Assert.assertEquals(BigDecimal.ZERO,costo);
	}
	@Test
	public void limiteSuperior() {
		BigDecimal costo=service.calculateCost(151,SubscriptionCategory.SILVER); 
		Assert.assertEquals(BigDecimal.ZERO,costo);
	}
	
	@Test
	public void edadInvalida1() {
		BigDecimal costo=service.calculateCost(15,SubscriptionCategory.SILVER); 
		Assert.assertEquals(BigDecimal.ZERO,costo);
	}
	
	@Test
	public void edadInvalida2() {
		BigDecimal costo=service.calculateCost(180,SubscriptionCategory.SILVER); 
		Assert.assertEquals(BigDecimal.ZERO,costo);
	}
	/**
	 * Clase 2
	 
	 
	 @Test
	public void categoriaInvalida1() {
		//BigDecimal costo=service.calculateCost(19,SubscriptionCategory.HOLA); 
		fail(service.calculateCost(19,SubscriptionCategory.HOLA));
	}
	 @Test
	public void categoriaInvalida2() {
		//BigDecimal costo=service.calculateCost(19,SubscriptionCategory.NOEXISTE); 
		fail(service.calculateCost(19,SubscriptionCategory.NOEXISTE));
	}
	
	 @Test
	public void categoriaInvalida3() {
		//BigDecimal costo=service.calculateCost(19,SubscriptionCategory.ADIOS); 
		fail(service.calculateCost(19,SubscriptionCategory.ADIOS) );
	}
	*/
	
	 /**
	 * Clase 2
	 
	 */
	 
	 @Test
	public void clase2valida1() {
		BigDecimal costo=service.calculateCost(18,SubscriptionCategory.GOLD); 
		BigDecimal costoCorrecto= new BigDecimal(17000);
		Assert.assertEquals(costoCorrecto,costo);
	}
	@Test
	public void clase2valida2() {
		BigDecimal costoCorrecto= new BigDecimal(12750);
		BigDecimal costo=service.calculateCost(25,SubscriptionCategory.SILVER); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase2valida3() {
		BigDecimal costoCorrecto= new BigDecimal(17000);
		BigDecimal costo=service.calculateCost(20,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase2valida4() {
		BigDecimal costoCorrecto= new BigDecimal(25500);
		BigDecimal costo=service.calculateCost(23,SubscriptionCategory.DIAMOND); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	
	
	 /**
	 * Clase 3
	 */
	 public void clase3valida1() {
		BigDecimal costoCorrecto= new BigDecimal(17600);
		BigDecimal costo=service.calculateCost(26,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	@Test
	public void clase3valida2() {
		BigDecimal costoCorrecto= new BigDecimal(13200);
		BigDecimal costo=service.calculateCost(30,SubscriptionCategory.SILVER); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase3valida3() {
		BigDecimal costoCorrecto= new BigDecimal(17600);
		BigDecimal costo=service.calculateCost(28,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase3valida4() {
		BigDecimal costoCorrecto= new BigDecimal(26400);
		BigDecimal costo=service.calculateCost(27,SubscriptionCategory.DIAMOND); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 
	 /**
	 * Clase 4
	 */
	 
	 public void clase4valida1() {
		BigDecimal costoCorrecto= new BigDecimal(18000);
		BigDecimal costo=service.calculateCost(31,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	@Test
	public void clase4valida2() {
		BigDecimal costoCorrecto= new BigDecimal(13500);
		BigDecimal costo=service.calculateCost(60,SubscriptionCategory.SILVER); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase4valida3() {
		BigDecimal costoCorrecto= new BigDecimal(18000);
		BigDecimal costo=service.calculateCost(40,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase4valida4() {
		BigDecimal costoCorrecto= new BigDecimal(27000);
		BigDecimal costo=service.calculateCost(45,SubscriptionCategory.DIAMOND); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 /**
	 * Clase 5
	 */
	 
	 public void clase5valida1() {
		BigDecimal costoCorrecto= new BigDecimal(16000);
		BigDecimal costo=service.calculateCost(61,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	@Test
	public void clase5valida2() {
		BigDecimal costoCorrecto= new BigDecimal(12000);
		BigDecimal costo=service.calculateCost(150,SubscriptionCategory.SILVER); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase5valida3() {
		BigDecimal costoCorrecto= new BigDecimal(16000);
		BigDecimal costo=service.calculateCost(80,SubscriptionCategory.GOLD); 
		Assert.assertEquals(costoCorrecto,costo);
	}
	 @Test
	public void clase5valida4() {
		BigDecimal costoCorrecto= new BigDecimal(24000);
		BigDecimal costo=service.calculateCost(90,SubscriptionCategory.DIAMOND); 
		Assert.assertEquals(costoCorrecto,costo);
	}
}
